package com.hspedu.qqframe;

import com.hspedu.qqserver.service.QQServer;

/**
 * @author 赵好运
 * @version 1.0
 * 该类创建QQServer，启动服务器
 **/
public class QQFrame {
    public static void main(String[] args) {
        new QQServer();
    }
}
