package com.hspedu.qqserver.service;

import java.util.HashMap;
import java.util.Iterator;

/**
 * @author 赵好运
 * @version 1.0
 * 该类 用于管理和服务端通信的线程
 **/
public class ManageClientThreads {
    private static HashMap<String,ServerConnectClientThread> hashMap = new HashMap<>();
    //添加线程对象到hashMap集合
    public static void addClient(String userId,ServerConnectClientThread serverConnectClientThread) {
        hashMap.put(userId,serverConnectClientThread);
    }
    //移除指定的线程对象
    public static void removeClient(String userId) {
        hashMap.remove(userId);
    }
    //根据userId获取线程对象
    public static ServerConnectClientThread getServerConnectClientThread(String userId) {
        return hashMap.get(userId);
    }
    //返回在线用户列表
    public static String getOnlineUser() {
        //遍历hashmap
        Iterator<String> iterator = hashMap.keySet().iterator();//迭代器遍历key，即用户id，而非用户对象
        String onlineUserList = "";
        while (iterator.hasNext()) {
            onlineUserList += iterator.next().toString() + " ";
        }
        return onlineUserList;
    }

    public static HashMap<String, ServerConnectClientThread> getHashMap() {
        return hashMap;
    }
}
