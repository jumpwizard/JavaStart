package com.hspedu.qqserver.service;

import com.hspedu.qqcommon.Message;
import com.hspedu.qqcommon.MessageType;
import com.hspedu.utils.Utility;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

/**
 * @author 赵好运
 * @version 1.0
 **/
public class SendNewsToAllService implements Runnable{
    @Override
    public void run() {
        while (true) {
            System.out.println("请输入服务器要推送的消息【输入exit退出推送消息线程】");
            String news = Utility.readString(100);
            if (news.equals("exit")) {
                break;
            }
            //构建消息
            Message message = new Message();
            message.setMessageType(MessageType.MESSAGE_TO_ALL_MES);
            message.setSender("服务器");
            message.setContent(news);
            message.setSendTime(new Date().toString());
            System.out.println("服务器推送消息给所有人说：" + news);
            //遍历发送给所有在线用户
            HashMap<String, ServerConnectClientThread> hashMap = ManageClientThreads.getHashMap();
            Iterator<String> iterator = hashMap.keySet().iterator();
            while (iterator.hasNext()) {
                String onlineUserId = iterator.next();
                try {
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientThreads.
                            getServerConnectClientThread(onlineUserId).getSocket().getOutputStream());
                    objectOutputStream.writeObject(message);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
