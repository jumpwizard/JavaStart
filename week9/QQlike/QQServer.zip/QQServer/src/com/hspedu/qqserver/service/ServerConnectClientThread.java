package com.hspedu.qqserver.service;

import com.hspedu.qqcommon.Message;
import com.hspedu.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author 赵好运
 * @version 1.0
 * 该类的一个对象和客户端保持通讯
 **/
public class ServerConnectClientThread extends Thread{
    private Socket socket;
    private String userId;//连接到服务端的用户Id

    public ServerConnectClientThread(Socket socket, String userId) {
        this.socket = socket;
        this.userId = userId;
    }

    @Override
    public void run() {//收发消息的线程
        while (true) {
            System.out.println("服务端和客户端" + userId + "保持通信，读取数据...");
            try {
                //创建流收发数据
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream objectOutputStream = null;
                Message message = (Message) objectInputStream.readObject();
                //根据message的类型做相应处理
                switch (message.getMessageType()) {
                    //返回在线用户列表
                    case MessageType.MESSAGE_GET_ONLINE_FRIEND:
                        System.out.println(message.getSender() + "要求在线用户列表");
                        String onlineUser = ManageClientThreads.getOnlineUser();
                        //向客户端发送message对象
                        Message message2 = new Message();
                        message2.setMessageType(MessageType.MESSAGE_RET_ONLINE_FRIEND);
                        message2.setContent(onlineUser);
                        message2.setGetter(message.getSender());
                        //创建流
                        objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject(message2);
                        break;
                    //私聊
                    case MessageType.MESSAGE_COMM_MES:
                        //根据接收方id获取对应该客户端的线程连接socket输出流
                        ServerConnectClientThread getterThread = ManageClientThreads.getServerConnectClientThread(message.getGetter());
                        if (getterThread != null) {
                            objectOutputStream = new ObjectOutputStream(getterThread.getSocket().getOutputStream());
                            objectOutputStream.writeObject(message);
                        } else {
                            //如果用户不在线，可以保存到数据库，实现离线留言
                            ArrayList<Message> messages = QQServer.getOffLineDb().get(message.getGetter());
                            if (messages == null) {
                                QQServer.getOffLineDb().put(message.getGetter(),new ArrayList<Message>());
                                messages = QQServer.getOffLineDb().get(message.getGetter());
                            }
                            messages.add(message);
                        }
                        break;
                    //群发消息
                    case MessageType.MESSAGE_TO_ALL_MES:
                        HashMap<String, ServerConnectClientThread> hashMap = ManageClientThreads.
                                getHashMap();
                        Iterator<String> iterator = hashMap.keySet().iterator();
                        while (iterator.hasNext()) {
                            String onlineUserId = iterator.next();
                            if (!onlineUserId.equals(message.getSender())) {
                                objectOutputStream = new ObjectOutputStream(ManageClientThreads.
                                        getServerConnectClientThread(onlineUserId).socket.
                                        getOutputStream());
                                objectOutputStream.writeObject(message);
                            }
                        }
                        break;
                    //文件传输
                    case MessageType.MESSAGE_FILE_MES:
                        //根据接收方id获取对应该客户端的线程连接socket输出流
                        objectOutputStream = new ObjectOutputStream(ManageClientThreads.
                                getServerConnectClientThread(message.getGetter())
                                .getSocket().getOutputStream());
                        objectOutputStream.writeObject(message);
                        break;
                    //客户端退出，结束相应线程
                    case MessageType.MESSAGE_CLIENT_EXIT:
                        System.out.println(message.getSender() + "退出");
                        //从在线线程集合中删除
                        ManageClientThreads.removeClient(message.getSender());
                        socket.close();//关闭连接
                        //退出线程
                        return;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
