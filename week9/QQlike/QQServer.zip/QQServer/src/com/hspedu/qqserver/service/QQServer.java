package com.hspedu.qqserver.service;

import com.hspedu.qqcommon.Message;
import com.hspedu.qqcommon.MessageType;
import com.hspedu.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author 赵好运
 * @version 1.0
 * 服务器，在监听9999端口，等待客户端的连接，接受请求并验证，若验证成功则创建通信线程
 **/
public class QQServer {
    private ServerSocket serverSocket = null;
    //存放合法用户的信息（不会数据库，暂时先使用集合）(也可以使用ConcurrentHashMap，可以处理并发的集合，没有线程安全问题)
    private static ConcurrentHashMap<String,User> validUsers = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, ArrayList<Message>> offLineDb = new ConcurrentHashMap<>();
    static {//在静态代码块初始化validUsers
        validUsers.put("zhy", new User("zhy", "123456"));
        validUsers.put("wyt", new User("wyt", "123456"));
        validUsers.put("ckq", new User("ckq", "123456"));
    }
    //验证用户是否合法的方法
    private boolean checkUser(String userId, String passwd) {
        User user = validUsers.get(userId);
        if (user == null) {//该用户不存在
            return false;
        } else if (!user.getPasswd().equals(passwd)) {//密码不正确
            return false;
        } else {//验证成功
            return true;
        }
    }
    //用户上线时，将其离线留言和待收文件发给他
    private void sendOffMessages(String getterId) {
        ArrayList<Message> messages = offLineDb.get(getterId);
        if (messages != null) {
            try {
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientThreads.
                        getServerConnectClientThread(getterId).getSocket().getOutputStream());
                for (int i = 0; i < messages.size(); i++) {
                    objectOutputStream.writeObject(messages.get(i));
                    Thread.sleep(50);
                }
                offLineDb.remove(getterId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public QQServer() {
        //这里的端口是指定好的，在实际开发中可以写在配置文件中
        System.out.println("服务端在9999端口监听....");
        try {
            serverSocket = new ServerSocket(9999);
            new Thread(new SendNewsToAllService()).start();//启动服务器推送消息线程
            while (true) {//持续监听，与每个发出请求的客户端建立连接
                //接受socket连接
                Socket socket = serverSocket.accept();
                //创建流
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                //创建Message对象，用于回复
                Message message = new Message();
                User user = (User)objectInputStream.readObject();//读取客户端发送的User对象
                //验证身份，目前还没学数据库，只能用IO流存储用户，这里先写死
                if (checkUser(user.getUserID(),user.getPasswd())) {//合法
                    message.setMessageType(MessageType.MESSAGE_LOGIN_SUCCEED);
                    //发送Message对象回复客户端
                    objectOutputStream.writeObject(message);
                    //创建一个线程和客户端保持通讯
                    ServerConnectClientThread serverConnectClientThread = new
                            ServerConnectClientThread(socket, user.getUserID());
                    serverConnectClientThread.start();//启动该线程
                    //把该线程对象放到一个集合中进行管理
                    ManageClientThreads.addClient(user.getUserID(),serverConnectClientThread);
                    //向该客户端发送离线消息
                    sendOffMessages(user.getUserID());
                } else {//登陆失败
                    System.out.println("用户 " + user.getUserID() + "登陆失败");
                    message.setMessageType(MessageType.MESSAGE_LOGIN_FAIL);
                    objectOutputStream.writeObject(message);
//                    objectInputStream.close();
//                    objectOutputStream.close();
                    socket.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    public static ConcurrentHashMap<String, User> getValidUsers() {
        return validUsers;
    }

    public static void setValidUsers(ConcurrentHashMap<String, User> validUsers) {
        QQServer.validUsers = validUsers;
    }

    public static ConcurrentHashMap<String, ArrayList<Message>> getOffLineDb() {
        return offLineDb;
    }

    public static void setOffLineDb(ConcurrentHashMap<String, ArrayList<Message>> offLineDb) {
        QQServer.offLineDb = offLineDb;
    }
}
