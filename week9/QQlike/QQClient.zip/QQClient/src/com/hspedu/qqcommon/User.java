package com.hspedu.qqcommon;

import java.io.Serializable;

/**
 * @author 赵好运
 * @version 1.0
 * 表示一个用户/客户信息
 **/
public class User implements Serializable {//实现序列化，使之能在网络上传输
    //版本序列号，增加兼容性
    private static final long serialVersionUID = 1L;
    private String userID;//用户Id
    private String passwd;//用户密码

    public User() {
    }

    public User(String userID, String passwd) {
        this.userID = userID;
        this.passwd = passwd;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }
}
