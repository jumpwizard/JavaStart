package com.hspedu.qqclient.frame;

import com.hspedu.qqclient.view.QQView;

/**
 * @author 赵好运
 * @version 1.0
 * 程序的入口，进入登陆界面
 **/
public class QQFrame {
    public static void main(String[] args) throws Exception {
        new QQView().mainMenu();
        System.out.println("客户端退出系统...");
    }
}
