package com.hspedu.qqclient.service;

import com.hspedu.qqcommon.Message;
import com.hspedu.qqcommon.MessageType;
import com.hspedu.qqcommon.User;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author 赵好运
 * @version 1.0
 * 该类的一个对象和服务端保持通信
 **/
public class ClientConnectServerThread extends Thread{
    private Socket socket;

    @Override
    public void run() {
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream objectOutputStream = null;
            //因为线程需要在后台和服务器通信，因此用while循环
            while (true) {
                System.out.println("客户端线程，等待读取从服务端发送的消息");
                //若未收到消息，则会等待（即阻塞在这里）
                Message message = (Message) objectInputStream.readObject();
                //判断message类型，并做相应的处理
                switch (message.getMessageType()) {
                    case MessageType.MESSAGE_RET_ONLINE_FRIEND:
                        //取出在线用户信息并显示
                        String[] onlineUsers = message.getContent().split(" ");
                        System.out.println("===========当前在线用户列表============");
                        for (int i = 0; i < onlineUsers.length; i++) {
                            System.out.println("用户：" + onlineUsers[i]);
                        }
                        break;
                    case MessageType.MESSAGE_COMM_MES:
                        System.out.println(message.getSender() + "对" + message.getGetter() + "说：" +
                                message.getContent());
                        break;
                    case MessageType.MESSAGE_TO_ALL_MES:
                        System.out.println(message.getSender() + "对所有在线用户说：" +
                                message.getContent());
                        break;
                    case MessageType.MESSAGE_FILE_MES:
                        System.out.println(message.getSender() + "给" + message.getGetter()
                                + "发送文件：" + message.getSrc() + "到" + message.getDest());
                        //取出message中的文件字节数组，通过文件输出流写入到磁盘
                        FileOutputStream fileOutputStream = new FileOutputStream(message.getDest());
                        fileOutputStream.write(message.getFileBytes());
                        fileOutputStream.close();
                        System.out.println("保存文件成功");
                        break;
                    default:
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ClientConnectServerThread(Socket socket) {
        this.socket = socket;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }
}
