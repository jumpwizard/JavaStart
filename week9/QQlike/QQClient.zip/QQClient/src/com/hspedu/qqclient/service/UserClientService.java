package com.hspedu.qqclient.service;

import com.hspedu.qqclient.utils.Utility;
import com.hspedu.qqcommon.Message;
import com.hspedu.qqcommon.MessageType;
import com.hspedu.qqcommon.User;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;

/**
 * @author 赵好运
 * @version 1.0
 * 实现客户端的各种服务（验证用户身份，获取在线用户列表,聊天退出等）
 **/
public class UserClientService {
    //创建user成员
    private User user = new User();
    //创建Socket成员
    private Socket socket;

    //根据userId 和 pwd到服务器验证该用户是否合法
    public boolean checkUser(String userId,String pwd) throws Exception{
        boolean b = false;//判断是否合法
        //对象初始化
        user.setUserID(userId);
        user.setPasswd(pwd);
        //连接到服务端，发送user对象
        socket = new Socket(InetAddress.getLocalHost(),9999);//连接服务器
        //创建流发送对象
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        objectOutputStream.writeObject(user);
        //读取从服务器回复的Message对象
        ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
        Message message = (Message) objectInputStream.readObject();

        if (message.getMessageType().equals(MessageType.MESSAGE_LOGIN_SUCCEED)) {//登陆成功
            //创建一个和服务器端保持通信的线程（创建一个线程类 ClientConnectServerThread）
            ClientConnectServerThread clientConnectServerThread = new ClientConnectServerThread(socket);
            clientConnectServerThread.start();//启动客户端的线程
            //在通信过程中，一个客户端与服务端之间可能有多条线程,分别用于传输文件，消息，视频通话等，所以需要创建集合管理线程
            ManageClientConnectServerThread.addClientConnectServerThread(userId,clientConnectServerThread);
            b = true;
        } else {//若登陆失败，我们不启动和服务器通信的线程，释放资源
//            objectOutputStream.close();
//            objectInputStream.close();
            socket.close();
        }
        return b;
    }
    //向服务器端请求在线用户列表
    public void onlineFriendList() {
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_GET_ONLINE_FRIEND);
        message.setSender(user.getUserID());
        //向服务器发送请求
        try {
            //创建流
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                    ManageClientConnectServerThread.getClientConnectServerThread(user.getUserID())
                            .getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //私聊
    public void sendMessageToOne() {
        System.out.println("请输入要私聊的用户id（在线）");
        String getterId = Utility.readString(50);
        //查询用户是否在线/合法
        //...
        System.out.println("请输入要发送的信息");
        String content = Utility.readString(1000);
        //创建信息
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_COMM_MES);
        message.setSender(user.getUserID());
        message.setGetter(getterId);
        message.setContent(content);
        message.setSendTime(new java.util.Date().toString());
        System.out.println(user.getUserID() + "对" + getterId + "说：" + content);
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //群发消息
    public void sendMessageToAll() {
        System.out.println("请输入要群发的消息内容：");
        String content = Utility.readString(1000);
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_TO_ALL_MES);
        message.setSender(user.getUserID());
        message.setContent(content);
        message.setSendTime(new Date().toString());
        System.out.println(user.getUserID() + "对所有在线用户说：" + content);

        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread(user.getUserID())
                                    .getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //发送文件

    /**
     *
     * @param src 源文件
     * @param dest 文件目的路径
     * @param senderId 发送方id
     * @param getterId 接收方id
     */
    public void sendFileToOne(String src, String dest,String senderId,String getterId) {
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_FILE_MES);
        message.setSender(senderId);
        message.setGetter(getterId);
        message.setSrc(src);
        message.setDest(dest);
        //读取文件
        FileInputStream fileInputStream = null;
        byte[] bytes = new byte[(int)new File(src).length()];
        try {
            fileInputStream = new FileInputStream(src);
            fileInputStream.read(bytes);//将src文件读入到字节数组
            message.setFileBytes(bytes);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        //提示信息
        System.out.println(senderId + "给" + getterId + "发送文件：" + src + "到对方的" + dest);
        //发送
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread(user.getUserID()).
                            getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //退出客户端并给服务器发送退出信息
    public void logout() {
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_CLIENT_EXIT);
        message.setSender(user.getUserID());
        try {
            //直接获取socket，方便简洁，但当该客户端有多个socket时会混乱
//            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            //通过线程获取socket，可以精确的获取到要关闭的socket
            ObjectOutputStream objectOutputStream = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread
                            (user.getUserID()).getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
            System.out.println(user.getUserID() + "退出系统");
            System.exit(0);//结束进程（该客户端所有未关闭的线程都会退出）;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
