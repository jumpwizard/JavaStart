package com.hspedu.qqclient.view;

import com.hspedu.qqclient.service.ManageClientConnectServerThread;
import com.hspedu.qqclient.service.UserClientService;
import com.hspedu.qqclient.utils.Utility;

/**
 * @author 赵好运
 * @version 1.0
 * 客户端的登录登录界面和登陆成功后的菜单界面
 **/
public class QQView {
    private boolean loop = true;//控制是否显示菜单
    private String key = "";//接受用户的键盘输入
    private UserClientService userClientService = new UserClientService();//用于登录用户/注册服务

    public void mainMenu() throws Exception {
        while (loop) {
            System.out.println("==============欢迎登录网络通信界面==================");
            System.out.println("\t\t 1 登陆系统");
            System.out.println("\t\t 9 退出系统");

            key = Utility.readString(1);
            //根据用户的不同输入来处理逻辑
            switch (key) {
                case "1":
                    System.out.print("请输入用户账号：");
                    String userId = Utility.readString(50);
                    System.out.print("请输入密码：");
                    String pwd = Utility.readString(50);
                    //到服务端验证是否合法
                    if (userClientService.checkUser(userId,pwd)) {//若验证成功
                        System.out.println("==============欢迎 (用户 " + userId + ")==================");
                        //进入二级菜单
                        while (loop) {
                            System.out.println("\n==============网络通信系统二级菜单" +
                                    "（用户 " + userId + "）==================");
                            System.out.println("\t\t 1 显示在线用户列表");
                            System.out.println("\t\t 2 群发消息");
                            System.out.println("\t\t 3 私聊消息");
                            System.out.println("\t\t 4 发送文件");
                            System.out.println("\t\t 9 退出系统");
                            System.out.println("请输入你的选择：");
                            key = Utility.readString(1);
                            switch (key) {
                                case "1" :
                                    userClientService.onlineFriendList();
                                    break;
                                case "2" :
                                    userClientService.sendMessageToAll();
                                    break;
                                case "3" :
                                    userClientService.sendMessageToOne();
                                    break;
                                case "4" :
                                    System.out.println("请输入要把文件发送给给的用户（在线）：");
                                    String getterId = Utility.readString(50);
                                    System.out.println("请输入发送文件的路径：");
                                    String src = Utility.readString(100);
                                    System.out.println("请输入对方的文件保存路径：");
                                    String dest = Utility.readString(100);
                                    userClientService.sendFileToOne(src,dest,userId,getterId);
                                    break;
                                case "9" :
                                    userClientService.logout();//向服务器提示退出并结束进程
                                    break;
                                default:
                                    break;
                            }
                        }
                    } else {//验证失败
                        System.out.println("登陆失败");
                    }

                    break;
                case "9" :
                    loop = false;
                    System.out.println("退出系统");
                    break;
                default:
                    System.out.println("输入错误，请重新输入");
                    break;

            }
        }
    }

}
