package com.hspedu.qqclient.service;

import java.util.HashMap;

/**
 * @author 赵好运
 * @version 1.0
 * 在通信过程中，一个客户端与服务端之间可能有多条线程,分别用于传输文件，消息，视频通话等，该类用于管理客户端线程
 **/
public class ManageClientConnectServerThread {
    //该集合用于管理线程，key是用户id，v是线程
    private static HashMap<String,ClientConnectServerThread> hm = new HashMap<>();
    //将线程加入到集合
    public static void addClientConnectServerThread(String userId,ClientConnectServerThread clientConnectServerThread) {
        hm.put(userId,clientConnectServerThread);
    }
    //通过userId可得到对应线程
    public  static ClientConnectServerThread getClientConnectServerThread(String userId) {
        return hm.get(userId);
    }
}
